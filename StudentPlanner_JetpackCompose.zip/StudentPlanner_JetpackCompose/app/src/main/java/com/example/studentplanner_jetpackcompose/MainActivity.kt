@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package com.example.studentplanner // Sesuaikan dengan package / namespace proyekmu.
import androidx.compose.material.icons.Icons
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale
import java.util.UUID


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val context = LocalContext.current
            val store = remember { PlannerStore(context) }
            val data = remember { store.load() }
            PlannerTheme { StudentPlanner(data, store::save) }
        }
    }
}

private val Indonesian = Locale.forLanguageTag("id-ID")
private val Days = listOf("Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu")
private val Red = Color(0xFFF44336)
private val Green = Color(0xFF4CAF50)
private val Orange = Color(0xFFEF6C00)
private fun LocalDate.display() = format(DateTimeFormatter.ofPattern("d MMM yyyy", Indonesian))
private fun daysLeft(date: LocalDate) = ChronoUnit.DAYS.between(LocalDate.now(), date).toInt()
private fun remaining(date: LocalDate): String = when (val days = daysLeft(date)) {
    in Int.MIN_VALUE..-1 -> "Terlambat"
    0 -> "Hari ini"
    else -> "$days hari lagi"
}

data class ClassSchedule(
    val id: String = UUID.randomUUID().toString(),
    val subject: String, val lecturer: String, val day: String,
    val start: String, val end: String, val room: String
)
data class PlannerTask(
    val id: String = UUID.randomUUID().toString(),
    val title: String, val subject: String, val deadline: LocalDate, val note: String
)
data class PlannerData(
    val schedules: List<ClassSchedule> = emptyList(),
    val tasks: List<PlannerTask> = emptyList()
)

// Penyimpanan mandiri untuk prototipe. Tidak memakai database Drift dari Flutter.
private class PlannerStore(context: Context) {
    private val prefs = context.getSharedPreferences("student_planner_compose", Context.MODE_PRIVATE)
    fun load(): PlannerData {
        val root = JSONObject(prefs.getString("data", null) ?: return PlannerData())
        val schedules = root.optJSONArray("schedules") ?: JSONArray()
        val tasks = root.optJSONArray("tasks") ?: JSONArray()
        return PlannerData(
            List(schedules.length()) { i -> schedules.getJSONObject(i).let {
                ClassSchedule(it.getString("id"), it.getString("subject"), it.getString("lecturer"),
                    it.getString("day"), it.getString("start"), it.getString("end"), it.getString("room"))
            } },
            List(tasks.length()) { i -> tasks.getJSONObject(i).let {
                PlannerTask(it.getString("id"), it.getString("title"), it.getString("subject"),
                    LocalDate.parse(it.getString("deadline")), it.getString("note"))
            } }
        )
    }
    fun save(data: PlannerData) {
        val schedules = JSONArray()
        data.schedules.forEach { s -> schedules.put(JSONObject().apply {
            put("id", s.id); put("subject", s.subject); put("lecturer", s.lecturer)
            put("day", s.day); put("start", s.start); put("end", s.end); put("room", s.room)
        }) }
        val tasks = JSONArray()
        data.tasks.forEach { t -> tasks.put(JSONObject().apply {
            put("id", t.id); put("title", t.title); put("subject", t.subject)
            put("deadline", t.deadline.toString()); put("note", t.note)
        }) }
        prefs.edit().putString("data", JSONObject().put("schedules", schedules)
            .put("tasks", tasks).toString()).apply()
    }
}

@Composable
fun PlannerTheme(dark: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    val colors = if (dark) darkColorScheme(
        primary = Color(0xFFAAC7FF), onPrimary = Color(0xFF002F65),
        primaryContainer = Color(0xFF17457F), surface = Color(0xFF1B1B1F),
        background = Color(0xFF121316)
    ) else lightColorScheme(
        primary = Color(0xFF1565C0), onPrimary = Color.White,
        primaryContainer = Color(0xFFD7E3FF), onPrimaryContainer = Color(0xFF001B3F),
        surface = Color.White, background = Color(0xFFF8F9FC)
    )
    MaterialTheme(colorScheme = colors, content = content)
}

private data class Destination(val label: String, val icon: ImageVector)
private val Destinations = listOf(
    Destination("Home", Icons.Outlined.Home), Destination("Jadwal", Icons.Outlined.CalendarMonth),
    Destination("Tugas", Icons.Outlined.Assignment), Destination("Absensi", Icons.Outlined.BarChart),
    Destination("Kalender", Icons.Outlined.EventNote), Destination("Setting", Icons.Outlined.Settings)
)

@Composable
fun StudentPlanner(initialData: PlannerData = PlannerData(), onSave: (PlannerData) -> Unit = {}) {
    var data by remember { mutableStateOf(initialData) }
    var selected by rememberSaveable { mutableIntStateOf(0) }
    var showForm by rememberSaveable { mutableStateOf(false) }
    var editId by rememberSaveable { mutableStateOf<String?>(null) }
    var noteId by rememberSaveable { mutableStateOf<String?>(null) }
    var doneId by rememberSaveable { mutableStateOf<String?>(null) }
    fun update(next: PlannerData) { data = next; onSave(next) }
    BackHandler(enabled = selected != 0 && !showForm && noteId == null && doneId == null) { selected = 0 }
    val colors = MaterialTheme.colorScheme
    BoxWithConstraints(Modifier.fillMaxSize().background(colors.background)) {
        val useRail = maxWidth >= 600.dp && maxHeight >= 480.dp
        val expanded = maxWidth >= 1000.dp
        Row(Modifier.fillMaxSize()) {
            if (useRail) {
                NavigationRail(modifier = Modifier.fillMaxHeight().verticalScroll(rememberScrollState()),
                    containerColor = colors.surface) {
                    Spacer(Modifier.height(12.dp))
                    Destinations.forEachIndexed { index, destination ->
                        NavigationRailItem(selected == index, { selected = index },
                            icon = { Icon(destination.icon, contentDescription = null) },
                            label = { Text(destination.label) })
                    }
                }
            }
            Scaffold(
                modifier = Modifier.weight(1f), containerColor = colors.background,
                topBar = {
                    if (selected != 0) TopAppBar(
                        title = { Text(if (selected == 1) "Jadwal Kuliah" else Destinations[selected].label) },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = colors.primary, titleContentColor = colors.onPrimary))
                },
                bottomBar = {
                    if (!useRail) NavigationBar(containerColor = colors.surface) {
                        Destinations.forEachIndexed { index, destination ->
                            NavigationBarItem(selected == index, { selected = index },
                                icon = { Icon(destination.icon, contentDescription = destination.label) },
                                label = { Text(destination.label, fontSize = 10.sp, maxLines = 1) },
                                alwaysShowLabel = true)
                        }
                    }
                },
                floatingActionButton = {
                    if (selected == 1) FloatingActionButton(onClick = { editId = null; showForm = true }) {
                        Icon(Icons.Outlined.Add, "Tambah jadwal")
                    }
                    if (selected == 2) ExtendedFloatingActionButton(
                        onClick = { editId = null; showForm = true },
                        icon = { Icon(Icons.Outlined.Add, null) }, text = { Text("Tambah Tugas") })
                }
            ) { padding ->
                Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.TopCenter) {
                    Box(Modifier.widthIn(max = 1200.dp).fillMaxSize()) {
                        when (selected) {
                            0 -> HomePage(data, expanded) { selected = 4 }
                            1 -> SchedulePage(data.schedules, expanded,
                                onEdit = { editId = it.id; showForm = true },
                                onDelete = { item -> update(data.copy(schedules = data.schedules.filterNot { it.id == item.id })) })
                            2 -> TaskPage(data.tasks, expanded,
                                onEdit = { editId = it.id; showForm = true },
                                onDelete = { item -> update(data.copy(tasks = data.tasks.filterNot { it.id == item.id })) },
                                onDone = { doneId = it.id }, onNote = { noteId = it.id })
                            else -> MissingPage(selected)
                        }
                    }
                }
            }
        }
    }
    if (showForm && selected == 1) ScheduleForm(
        existing = data.schedules.find { it.id == editId },
        onDismiss = { showForm = false },
        onSubmit = { result ->
            update(data.copy(schedules = if (editId == null) data.schedules + result
            else data.schedules.map { if (it.id == editId) result else it }))
            showForm = false
        })
    if (showForm && selected == 2) TaskForm(
        existing = data.tasks.find { it.id == editId }, onDismiss = { showForm = false },
        onSubmit = { result ->
            update(data.copy(tasks = if (editId == null) data.tasks + result
            else data.tasks.map { if (it.id == editId) result else it }))
            showForm = false
        })
    data.tasks.find { it.id == noteId }?.let { task ->
        AlertDialog(onDismissRequest = { noteId = null }, title = { Text("Catatan Tugas") },
            text = { Text(task.note.ifBlank { "Belum ada catatan." },
                modifier = Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState())) },
            confirmButton = { TextButton(onClick = { noteId = null }) { Text("Tutup") } })
    }
    data.tasks.find { it.id == doneId }?.let { task ->
        AlertDialog(onDismissRequest = { doneId = null }, title = { Text("Tugas Selesai?") },
            text = { Text("Tandai \"${task.title}\" sebagai selesai dan hapus dari daftar?") },
            dismissButton = { TextButton(onClick = { doneId = null }) { Text("Batal") } },
            confirmButton = { Button(onClick = {
                update(data.copy(tasks = data.tasks.filterNot { it.id == doneId })); doneId = null
            }) { Text("Selesai") } })
    }
}

@Composable
private fun Panel(modifier: Modifier = Modifier, color: Color = MaterialTheme.colorScheme.surface,
                  content: @Composable ColumnScope.() -> Unit) {
    Card(modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = color),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = content)
    }
}

@Composable
private fun HomePage(data: PlannerData, expanded: Boolean, onAgenda: () -> Unit) {
    val colors = MaterialTheme.colorScheme
    val today = LocalDate.now()
    val classes = data.schedules.filter { it.day == Days[today.dayOfWeek.value - 1] }.sortedBy { it.start }
    val task = data.tasks.minByOrNull { it.deadline }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(today.format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Indonesian)),
                    fontSize = 13.sp, color = colors.onSurface.copy(alpha = .6f))
                Spacer(Modifier.height(4.dp))
                Text("Halo, Fajar! 👋", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            }
            Surface(shape = CircleShape, color = colors.primary, modifier = Modifier.size(44.dp)) {
                Box(contentAlignment = Alignment.Center) { Text("S", color = colors.onPrimary,
                    fontSize = 18.sp, fontWeight = FontWeight.Bold) }
            }
        }
        val schedule: @Composable () -> Unit = {
            Panel(color = colors.primary) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Jadwal hari ini", Modifier.weight(1f), fontSize = 14.sp,
                        color = colors.onPrimary.copy(alpha = .8f))
                    Pill("${classes.size} kelas", colors.onPrimary.copy(alpha = .15f), colors.onPrimary)
                }
                Spacer(Modifier.height(4.dp))
                if (classes.isEmpty()) Text("Tidak ada jadwal hari ini 🎉", fontSize = 18.sp,
                    color = colors.onPrimary, fontWeight = FontWeight.Bold)
                else {
                    val first = classes.first()
                    Text("Kelas berikutnya", fontSize = 12.sp, color = colors.onPrimary.copy(alpha = .7f))
                    Text(first.subject, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = colors.onPrimary)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Detail(Icons.Outlined.AccessTime, "${first.start} – ${first.end}", colors.onPrimary)
                        if (first.room.isNotBlank()) Detail(Icons.Outlined.LocationOn, first.room, colors.onPrimary)
                    }
                    if (classes.size > 1) {
                        HorizontalDivider(color = colors.onPrimary.copy(alpha = .2f))
                        classes.drop(1).forEach {
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text(it.start, color = colors.onPrimary, fontSize = 13.sp)
                                Text(it.subject, Modifier.weight(1f), color = colors.onPrimary, fontSize = 13.sp)
                                Text(it.room, color = colors.onPrimary.copy(alpha = .7f), fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
        val stats: @Composable () -> Unit = {
            BoxWithConstraints {
                // Stack the cards at narrow widths / larger accessibility font sizes.
                val stack = maxWidth < 300.dp || LocalDensity.current.fontScale > 1.3f
                val active: @Composable (Modifier) -> Unit = { modifier ->
                    Panel(modifier) {
                        Icon(Icons.Outlined.Assignment, null, tint = colors.primary, modifier = Modifier.size(28.dp))
                        Text("${data.tasks.size}", fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        Text("Tugas aktif", fontSize = 13.sp, color = colors.onSurfaceVariant)
                    }
                }
                val attendance: @Composable (Modifier) -> Unit = { modifier ->
                    Panel(modifier) {
                        Row(Modifier.heightIn(min = 100.dp), verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            CircularProgressIndicator(progress = { 0f }, color = Red,
                                trackColor = colors.onSurface.copy(alpha = .1f), strokeWidth = 5.dp,
                                modifier = Modifier.size(44.dp))
                            Column(Modifier.weight(1f)) {
                                Text("0.0%", color = Red, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                                Text("Kehadiran", fontSize = 13.sp, color = colors.onSurfaceVariant)
                            }
                        }
                    }
                }
                if (stack) Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    active(Modifier); attendance(Modifier)
                } else Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    active(Modifier.weight(1f)); attendance(Modifier.weight(1f))
                }
            }
        }
        if (expanded) Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Box(Modifier.weight(1f)) { schedule() }; Box(Modifier.weight(1f)) { stats() }
        } else { schedule(); stats() }
        if (task == null) Panel {
            Text("Deadline Terdekat", fontWeight = FontWeight.Bold)
            Detail(Icons.Outlined.CheckCircle, "Tidak ada tugas aktif")
        } else Panel(color = if (isSystemInDarkTheme()) colors.surface else Color(0xFFFFF3E0)) {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Outlined.WarningAmber, null, tint = Orange)
                Column(Modifier.widthIn(max = 600.dp)) {
                    Text("Deadline terdekat", fontSize = 11.sp, color = Orange, fontWeight = FontWeight.SemiBold)
                    Text(task.title, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text(task.deadline.display(), fontSize = 12.sp, color = colors.onSurfaceVariant)
                }
                Pill(remaining(task.deadline), if (daysLeft(task.deadline) <= 3) Red else colors.primary)
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Agenda Akademik", Modifier.weight(1f), fontSize = 16.sp, fontWeight = FontWeight.Bold)
            TextButton(onClick = onAgenda) { Text("Lihat semua", fontSize = 13.sp) }
        }
        Panel { Detail(Icons.Outlined.EventAvailable, "Tidak ada agenda mendatang") }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun Pill(text: String, color: Color, textColor: Color = Color.White) {
    Surface(color = color, shape = RoundedCornerShape(20.dp)) {
        Text(text, Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = textColor)
    }
}
@Composable
private fun Detail(icon: ImageVector, text: String, color: Color = MaterialTheme.colorScheme.onSurfaceVariant) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Icon(icon, null, modifier = Modifier.size(15.dp), tint = color)
        Text(text, fontSize = 13.sp, color = color)
    }
}
@Composable
private fun Action(icon: ImageVector, label: String, color: Color, onClick: () -> Unit) {
    IconButton(onClick, modifier = Modifier.background(color.copy(alpha = .1f), RoundedCornerShape(10.dp))) {
        Icon(icon, label, tint = color)
    }
}
@Composable
private fun EmptyPage(icon: ImageVector, text: String) {
    Column(Modifier.fillMaxSize().padding(24.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, modifier = Modifier.size(64.dp), tint = Color.Gray)
        Spacer(Modifier.height(16.dp))
        Text(text, color = Color.Gray, fontSize = 16.sp)
    }
}
@Composable
private fun SchedulePage(items: List<ClassSchedule>, expanded: Boolean,
                         onEdit: (ClassSchedule) -> Unit, onDelete: (ClassSchedule) -> Unit) {
    if (items.isEmpty()) { EmptyPage(Icons.Outlined.CalendarMonth, "Belum ada jadwal kuliah"); return }
    LazyVerticalGrid(columns = GridCells.Fixed(if (expanded) 2 else 1),
        contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 12.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        items(items, key = { it.id }) { item ->
            Panel {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(item.subject, Modifier.weight(1f), fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Action(Icons.Outlined.Edit, "Edit jadwal", MaterialTheme.colorScheme.primary) { onEdit(item) }
                    Action(Icons.Outlined.Delete, "Hapus jadwal", Red) { onDelete(item) }
                }
                Detail(Icons.Outlined.Person, "Dosen: ${item.lecturer}")
                Detail(Icons.Outlined.Event, "Hari: ${item.day}")
                Detail(Icons.Outlined.AccessTime, "Jam: ${item.start} - ${item.end}")
                Detail(Icons.Outlined.LocationOn, "Ruangan: ${item.room}")
            }
        }
    }
}
@Composable
private fun TaskPage(items: List<PlannerTask>, expanded: Boolean, onEdit: (PlannerTask) -> Unit,
                     onDelete: (PlannerTask) -> Unit, onDone: (PlannerTask) -> Unit, onNote: (PlannerTask) -> Unit) {
    if (items.isEmpty()) { EmptyPage(Icons.Outlined.AssignmentTurnedIn, "Belum ada tugas"); return }
    val colors = MaterialTheme.colorScheme
    LazyVerticalGrid(columns = GridCells.Fixed(if (expanded) 2 else 1),
        contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 12.dp, bottom = 110.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        items(items, key = { it.id }) { task ->
            Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = colors.surface),
                border = BorderStroke(1.dp, if (daysLeft(task.deadline) <= 3) Red.copy(alpha = .4f) else Color.Transparent)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(task.title, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    if (task.subject.isNotBlank()) Text(task.subject, fontSize = 13.sp, color = colors.onSurfaceVariant)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Detail(Icons.Outlined.CalendarToday, "Deadline: ${task.deadline.dayOfMonth}/${task.deadline.monthValue}/${task.deadline.year}")
                        Pill(remaining(task.deadline), if (daysLeft(task.deadline) <= 3) Red else colors.primary)
                    }
                    OutlinedButton(onClick = { onNote(task) }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(10.dp)) {
                        Icon(Icons.Outlined.StickyNote2, null, modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(8.dp)); Text("Lihat Catatan")
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { onDone(task) }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Color.White)) {
                            Icon(Icons.Outlined.Check, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp)); Text("Selesai")
                        }
                        Action(Icons.Outlined.Edit, "Edit tugas", colors.primary) { onEdit(task) }
                        Action(Icons.Outlined.Delete, "Hapus tugas", Red) { onDelete(task) }
                    }
                }
            }
        }
    }
}

// Ketiga file halaman berikut tidak ada dalam lampiran; jangan menebak layout aslinya.
@Composable
private fun MissingPage(index: Int) {
    Column(Modifier.fillMaxSize().padding(24.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Destinations[index].icon, null, modifier = Modifier.size(56.dp), tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(16.dp))
        Text(Destinations[index].label, style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        Text("Halaman ini belum tersedia pada versi Compose.")
    }
}

@Composable
private fun Field(value: String, label: String, onChange: (String) -> Unit, multiline: Boolean = false) {
    OutlinedTextField(value, onChange, label = { Text(label) }, modifier = Modifier.fillMaxWidth(),
        singleLine = !multiline, minLines = if (multiline) 3 else 1, shape = RoundedCornerShape(12.dp))
}
@Composable
private fun ScheduleForm(existing: ClassSchedule?, onDismiss: () -> Unit, onSubmit: (ClassSchedule) -> Unit) {
    var subject by rememberSaveable(existing?.id) { mutableStateOf(existing?.subject ?: "") }
    var lecturer by rememberSaveable(existing?.id) { mutableStateOf(existing?.lecturer ?: "") }
    var room by rememberSaveable(existing?.id) { mutableStateOf(existing?.room ?: "") }
    var day by rememberSaveable(existing?.id) { mutableStateOf(existing?.day ?: "Senin") }
    var start by rememberSaveable(existing?.id) { mutableStateOf(existing?.start ?: "08:00") }
    var end by rememberSaveable(existing?.id) { mutableStateOf(existing?.end ?: "09:40") }
    var error by rememberSaveable { mutableStateOf("") }
    var expanded by remember { mutableStateOf(false) }
    val context = LocalContext.current
    fun pickTime(value: String, update: (String) -> Unit) {
        val time = LocalTime.parse(value)
        TimePickerDialog(context, { _, hour, minute ->
            update(String.format(Locale.ROOT, "%02d:%02d", hour, minute))
        }, time.hour, time.minute, true).show()
    }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (existing == null) "Tambah Jadwal" else "Edit Jadwal") },
        text = {
            Column(Modifier.heightIn(max = 480.dp).verticalScroll(rememberScrollState()).imePadding(),
                verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Field(subject, "Mata kuliah *", { subject = it })
                Field(lecturer, "Dosen", { lecturer = it })
                Box {
                    OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text("Hari: $day") }
                    DropdownMenu(expanded, { expanded = false }) {
                        Days.forEach { value -> DropdownMenuItem(text = { Text(value) }, onClick = { day = value; expanded = false }) }
                    }
                }
                OutlinedButton(onClick = { pickTime(start) { start = it } }, modifier = Modifier.fillMaxWidth()) { Text("Mulai: $start") }
                OutlinedButton(onClick = { pickTime(end) { end = it } }, modifier = Modifier.fillMaxWidth()) { Text("Selesai: $end") }
                Field(room, "Ruangan", { room = it })
                if (error.isNotEmpty()) Text(error, color = MaterialTheme.colorScheme.error)
            }
        }, dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
        confirmButton = { Button(onClick = {
            error = when {
                subject.isBlank() -> "Mata kuliah wajib diisi."
                !LocalTime.parse(end).isAfter(LocalTime.parse(start)) -> "Jam selesai harus setelah jam mulai."
                else -> ""
            }
            if (error.isEmpty()) onSubmit(ClassSchedule(existing?.id ?: UUID.randomUUID().toString(),
                subject.trim(), lecturer.trim(), day, start, end, room.trim()))
        }) { Text("Simpan") } })
}
@Composable
private fun TaskForm(existing: PlannerTask?, onDismiss: () -> Unit, onSubmit: (PlannerTask) -> Unit) {
    var title by rememberSaveable(existing?.id) { mutableStateOf(existing?.title ?: "") }
    var subject by rememberSaveable(existing?.id) { mutableStateOf(existing?.subject ?: "") }
    var note by rememberSaveable(existing?.id) { mutableStateOf(existing?.note ?: "") }
    var date by rememberSaveable(existing?.id) { mutableStateOf((existing?.deadline ?: LocalDate.now()).toString()) }
    var error by rememberSaveable { mutableStateOf(false) }
    val context = LocalContext.current
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (existing == null) "Tambah Tugas" else "Edit Tugas") },
        text = {
            Column(Modifier.heightIn(max = 480.dp).verticalScroll(rememberScrollState()).imePadding(),
                verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Field(title, "Judul tugas *", { title = it })
                Field(subject, "Mata kuliah", { subject = it })
                OutlinedButton(onClick = {
                    val current = LocalDate.parse(date)
                    DatePickerDialog(context, { _, year, month, day ->
                        date = LocalDate.of(year, month + 1, day).toString()
                    }, current.year, current.monthValue - 1, current.dayOfMonth).show()
                }, modifier = Modifier.fillMaxWidth()) { Text("Deadline: ${LocalDate.parse(date).display()}") }
                Field(note, "Catatan", { note = it }, multiline = true)
                if (error) Text("Judul tugas wajib diisi.", color = MaterialTheme.colorScheme.error)
            }
        }, dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
        confirmButton = { Button(onClick = {
            error = title.isBlank()
            if (!error) onSubmit(PlannerTask(existing?.id ?: UUID.randomUUID().toString(),
                title.trim(), subject.trim(), LocalDate.parse(date), note.trim()))
        }) { Text("Simpan") } })
}

private fun demoData(): PlannerData = PlannerData(
    schedules = listOf(
        ClassSchedule(subject = "Pemrograman Mobile", lecturer = "Pak Fauzan",
            day = Days[LocalDate.now().dayOfWeek.value - 1], start = "08:00", end = "09:40", room = "Lab Game & Multimedia"),
        ClassSchedule(subject = "Metode Penelitian", lecturer = "Pak Alfan",
            day = Days[LocalDate.now().dayOfWeek.value - 1], start = "10:00", end = "11:40", room = "A-301")
    ), tasks = listOf(PlannerTask(title = "Membuat UI Jetpack Compose", subject = "Pemrograman Mobile",
        deadline = LocalDate.now().plusDays(2), note = "Buat layout adaptif untuk HP dan tablet."))
)
@Composable
private fun PhonePreview() { PlannerTheme(dark = false) { StudentPlanner() } }
@Preview(name = "HP • Home terisi", showBackground = true, widthDp = 393, heightDp = 852)
@Composable
private fun DemoPreview() { PlannerTheme(dark = false) { StudentPlanner(demoData()) } }
@Preview(name = "Tablet • Adaptif", showBackground = true, widthDp = 1280, heightDp = 800)
@Composable
private fun TabletPreview() { PlannerTheme(dark = false) { StudentPlanner(demoData()) } }
@Preview(name = "HP • Dark", showBackground = true, widthDp = 393, heightDp = 852,
    uiMode = android.content.res.Configuration.UI_MODE_NIGHT_YES)
@Composable
private fun DarkPreview() { PlannerTheme(dark = true) { StudentPlanner(demoData()) } }
@Preview(name = "Jadwal", showBackground = true, widthDp = 393, heightDp = 720)
@Composable
private fun SchedulePreview() { PlannerTheme(dark = false) { SchedulePage(demoData().schedules, false, {}, {}) } }
@Preview(name = "Tugas", showBackground = true, widthDp = 393, heightDp = 720)
@Composable
private fun TaskPreview() { PlannerTheme(dark = false) { TaskPage(demoData().tasks, false, {}, {}, {}, {}) } }
